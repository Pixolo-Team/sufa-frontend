# Operations screens - complete state capture

Every screen and state of `/operations`, for handing to a design system.

## mobile/ (430px wide, 2x retina)
| File | State |
| --- | --- |
| mobile-01-pin-gate | Locked - staff passcode keypad |
| mobile-02-home | Launcher, two tiles |
| mobile-03-batches-east-share-text | Batches, "Share as: Text" |
| mobile-04-batches-east-share-image | Batches, "Share as: Image" |
| mobile-05-batches-west | Batches, second center tab |
| mobile-06-payments-global-qr | Payments > Global QR (no amount) |
| mobile-07-fee-payment-empty | Fee Payment, nothing selected yet |
| mobile-08-fee-payment-filled | Fee Payment, all controls set + breakdown + QR |
| mobile-09-custom-empty | Custom, empty |
| mobile-10-custom-filled | Custom, amount + description + QR |

## desktop/ (1280px)
Same ten states. The layout changes at 992px to a persistent left rail
beside the panel, so these are a genuinely different composition.

## share-output/
What a parent actually receives - NOT app UI. Six share variants
(timings / fees / fees+timings, each as text and as a rendered PNG),
plus the Custom QR and its message.

## Notes for the redesign
- Structure should stay as-is; this is a restyle.
- Mobile-first: 430px is the primary target, coaches use it pitch-side.
- Tap targets are 44px minimum.
- Tab rows scroll sideways when options overflow (3 months / 2
  registration visible at a time) - do not make them wrap.
- All data is placeholder except the UPI ID.
